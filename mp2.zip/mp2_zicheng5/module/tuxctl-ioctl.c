/* tuxctl-ioctl.c
 *
 * Driver (skeleton) for the mp2 tuxcontrollers for ECE391 at UIUC.
 *
 * Mark Murphy 2006
 * Andrew Ofisher 2007
 * Steve Lumetta 12-13 Sep 2009
 * Puskar Naha 2013
 */

#include <asm/current.h>
#include <asm/uaccess.h>

#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/sched.h>
#include <linux/file.h>
#include <linux/miscdevice.h>
#include <linux/kdev_t.h>
#include <linux/tty.h>
#include <linux/spinlock.h>

#include "tuxctl-ld.h"
#include "tuxctl-ioctl.h"
#include "mtcp.h"

#define debug(str, ...) \
	printk(KERN_DEBUG "%s: " str, __FUNCTION__, ## __VA_ARGS__)

//static spinlock_t tuxctl_ioctl_lock = SPIN_LOCK_UNLOCKED;

//define the local variable here
static char button[2];          	 /* Store the latest input button */

static unsigned int available;       /* Indicate whether the Tux Controller is available
							 		  * 1 -- available
							 		  * 0 -- not available			   */

static unsigned int LED_state;		/* Indicate the state of current LED display mode
							 		 * 1 -- clock mode
							 		 * 0 -- user-mode			   */

static char LED_value;		/* store the value to be written into LED display*/
unsigned char reset[6];	/* array for holding previous state in case of reset */

/************************ Protocol Implementation *************************/

/* tuxctl_handle_packet()
 * IMPORTANT : Read the header for tuxctl_ldisc_data_callback() in 
 * tuxctl-ld.c. It calls this function, so all warnings there apply 
 * here as well.
 */
void tuxctl_handle_packet (struct tty_struct* tty, unsigned char* packet)
{
    //spin_lock_irqsave(&tuxctl_ioctl_lock, flags);
	int n = 2;				//length of input array
	//unsigned long flags;
	unsigned char buf[n];	// two opcode, len = 2
	
	unsigned a, b, c;

    a = packet[0]; /* Avoid printk() sign extending the 8-bit */
    b = packet[1]; /* values when printing them. */
    c = packet[2];

	switch(a) {
		case MTCP_RESET:
			// button = 1; 		//initialize the button to be up
			available = 1; 		//initialize the Tux Controller to be available
			LED_state = 0;		//initialize the LED display mode to be user mode
			LED_value = 0;		//initialize the LED value to be 0

			/* send these commands to initialize a TUX */
			buf[0] = MTCP_BIOC_ON;
			buf[1] = MTCP_LED_USR;

			/* use put function to send the command */
			tuxctl_ldisc_put(tty, buf, n);

			//spin_unlock_irqrestore(&tuxctl_ioctl_lock, flags);

			/* send data saved before reset to TUX */
			tuxctl_ldisc_put(tty, reset, 6);

			return;

		case MTCP_BIOC_EVENT:

		// 		button[0] = byte 1  
		//	+-7-6-5-4-+-3-+-2-+-1-+---0---+
		// 	| 1 X X X | C | B | A | START |
		// 	+---------+---+---+---+-------+
		// 	
		// 		button[1] = byte 2  
		//	+-7-6-5-4-+---3---+--2---+--1---+-0--+
		// 	| 1 X X X | right | down | left | up |
		// 	+---------+-------+------+------+----+

			button[0] = b;
			button[1] = c;
			return;

		case MTCP_ACK:
			available = 1;		//
			return;

    /*printk("packet : %x %x %x\n", a, b, c); */
	}
}

/******** IMPORTANT NOTE : READ THIS BEFORE IMPLEMENTING THE IOCTLS ************
 *                                                                            *
 * The ioctls should not spend any time waiting for responses to the commands *
 * they send to the controller. The data is sent over the serial line at      *
 * 9600 BAUD. At this rate, a byte takes approximately 1 millisecond to       *
 * transmit; this means that there will be about 9 milliseconds between       *
 * the time you request that the low-level serial driver send the             *
 * 6-byte SET_LEDS packet and the time the 3-byte ACK packet finishes         *
 * arriving. This is far too long a time for a system call to take. The       *
 * ioctls should return immediately with success if their parameters are      *
 * valid.                                                                     *
 *                                                                            *
 ******************************************************************************/
 int tuxctl_ioctl (struct tty_struct* tty, struct file* file, 
	      unsigned cmd, unsigned long arg)
{
	//spin_lock_irqsave(&tuxctl_ioctl_lock, flags);
	int n = 2;				//length of input array
	// unsigned long flags;
	unsigned char buf[n];	// two opcode, len = 2

	/* variables used for TUX_BUTTONS */
	unsigned char output;			/* final output RLDU CBAS to send to user */
	unsigned char lowbits;			/* temporary holder for 0000 CBAS  */
	unsigned char highbits;			/* temporary holder for RDLU 0000 */
	unsigned char fifth_bit;			/* temporary holder for 5th bit */
	unsigned char sixth_bit;			/* temporary holder for 6th bit */

	int i;
	int j;
	int k;

	unsigned char led_on;	// 4 bits indicate which display should be lit
	unsigned char dp_on;	// 4 bits indicate which decimal point should be lit
	unsigned char led_no_dp[16] = {0xE7, 0x06, 0xCB, 0x8F, 0x2E, 0xAD, 0xED, 0x86, 
									0xEF, 0xAE, 0xEE, 0x6D, 0xE1, 0x4F, 0xE9, 0xE8};
	unsigned char led_dp[16] = {0xF7, 0x16, 0xDB, 0x9F, 0x3E, 0xBD, 0xFD, 0x96, 
									0xFF, 0xBE, 0xFE, 0x7D, 0xF1, 0x5F, 0xF9, 0xF8};
	unsigned char led_index[4];		/* buffer that holds display data */


    switch (cmd) {

	case TUX_INIT:
		// button = 1; 		//initialize the button to be up
		available = 1; 		//initialize the Tux Controller to be available
		LED_state = 0;		//initialize the LED display mode to be user mode
		LED_value = 0;		//initialize the LED value to be 0

		/* send these commands to initialize a TUX */
		buf[0] = MTCP_BIOC_ON;
		buf[1] = MTCP_LED_USR;

		tuxctl_ldisc_put(tty, buf, n);

		//spin_unlock_irqrestore(&tuxctl_ioctl_lock, flags);

		return 0;

	case TUX_SET_LED:
		if(available == 0){
			return 0;
		}
		available = 0;

		n = 6;				//length of input array

		buf[0] = MTCP_LED_SET;
		/* intialize last five element in buf with zero*/
	 	for(i = 1; i < 6 ;i++){
			buf[i] = 0;
	 	}
		/* mask input arg and shift to get led_bit and dot_bit */
	 	led_on = (arg >> 16) & 0x0F;	/* get low 4bits of third byte */
	 	dp_on = (arg >> 24) & 0x0F;

		buf[1] = led_on & 0x0F;

		for(j = 0; j < 4 ; j++){
		 	led_index[j] = (arg >> (j*4)) & 0x0F;
			//choose decimal point version of display or not based on
			//the dp_on variable
			if(((dp_on >> j) & 0x01) == 1){		/* set dots to ON accordingly */
				buf[j+2] = led_dp[led_index[j]];
			}
			else{
				buf[j+2] = led_no_dp[led_index[j]];
			}
		} 
		/* save current state to a buffer for RESET */
		for(k = 0; k < 6; k++){
			reset[k] = buf[k];
		}

		tuxctl_ldisc_put(tty, buf, n);

		return 0;
	
	case TUX_BUTTONS:
		/* mask packet data and shift accordingly*/
		lowbits = (button[0] & 0xF0) >> 4;		/* 0000 CBAS */
		highbits = button[1] & 0xF0;			/* RDLU 0000 */

		/* mask 5th and 6th bit and swap them*/
		fifth_bit = highbits & 0x20;		/*detect the second bit*/		
		sixth_bit = highbits & 0x40;		/*detect the third bit*/	
		
		fifth_bit = fifth_bit << 1;
		sixth_bit = sixth_bit >> 1;

		highbits = highbits & 0x90;			/*detect the 4th and 7th bit*/

		highbits = (highbits | fifth_bit) | sixth_bit; 	/* RLDU 0000 */
		output = highbits | lowbits;			 		/* RLDU CBAS */

		/* send data to user and check if arg is NULL */
		if (copy_to_user((unsigned long*)arg, &output ,sizeof(output))){
			return -EINVAL;
		}
		else{
			return 0;
		}

	case TUX_LED_ACK:
		return -EINVAL;
	case TUX_LED_REQUEST:
		return -EINVAL;
	case TUX_READ_LED:
		return -EINVAL;
	default:
	    return -EINVAL;
	}
}
