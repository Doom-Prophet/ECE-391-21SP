#ifndef _INTERRUPTS_H
#define _INTERRUPTS_H

#ifndef ASM
#include "lib.h"
void keyboard_func();
void real_time_clock_func();

#endif


#endif
