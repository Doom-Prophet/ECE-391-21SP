#ifndef EXCEPTIONS_H
#define EXCEPTIONS_H

#include "exceptions.h"
#include "system_calls.h"
#ifndef ASM
/*
 *	Function: exception_divide_error
 *	Description: Raise the exception when divide error is detected
 *	inputs:		None
 *	outputs:	None
 *	effects:	Raise exception and print corresponding error info "Exception: divide error"
 */
void exception_divide_error(){
    printf("Exception: divide error\n");
    halt(HALT_MAGIC_NUMBER);
}

/*
 *	Function: exception_debug
 *	Description: Raise the exception when something wrong with the debug module is found
 *	inputs:		None
 *	outputs:	None
 *	effects:	Raise exception and print corresponding error info "Exception: debug"
 */
void exception_debug(){
    printf("Exception: debug\n");
    halt(HALT_MAGIC_NUMBER);
}

/*
 *	Function: exception_nmi_interrupt
 *	Description: Raise the exception when nmi interrupt is detected
 *	inputs:		None
 *	outputs:	None
 *	effects:	Raise exception and print corresponding error info "Exception: nmi interrupt"
 */
void exception_nmi_interrupt(){
    printf("Exception: nmi interrupt\n");
    halt(HALT_MAGIC_NUMBER);
}

/*
 *	Function: exception_breakpoint
 *	Description: Raise the exception when breakpoint is detected
 *	inputs:		None
 *	outputs:	None
 *	effects:	Raise exception and print corresponding error info "Exception: breakpoint"
 */
void exception_breakpoint(){
    printf("Exception: breakpoint\n");
    halt(HALT_MAGIC_NUMBER);
}

/*
 *	Function: exception_overflow
 *	Description: Raise the exception when overflow is detected
 *	inputs:		None
 *	outputs:	None
 *	effects:	Raise exception and print corresponding error info "Exception: overflow"
 */
void exception_overflow(){
    printf("Exception: overflow\n");
    halt(HALT_MAGIC_NUMBER);
}

/*
 *	Function: exception_bound_range_exceeded
 *	Description: Raise the exception when bound range exceeded is detected
 *	inputs:		None
 *	outputs:	None
 *	effects:	Raise exception and print corresponding error info "Exception: bound range exceeded"
 */
void exception_bound_range_exceeded(){
    printf("Exception: bound range exceeded\n");
    halt(HALT_MAGIC_NUMBER);
}

/*
 *	Function: exception_invalid_opcode
 *	Description: Raise the exception when invalid opcode is detected
 *	inputs:		None
 *	outputs:	None
 *	effects:	Raise exception and print corresponding error info "Exception: invalid opcode"
 */
void exception_invalid_opcode(){
    printf("Exception: invalid opcode\n");
    halt(HALT_MAGIC_NUMBER);
}

/*
 *	Function: exception_device_not_available
 *	Description: Raise the exception when device is not available
 *	inputs:		None
 *	outputs:	None
 *	effects:	Raise exception and print corresponding error info "Exception: device not available"
 */
void exception_device_not_available(){
    printf("Exception: device not available\n");
    halt(HALT_MAGIC_NUMBER);
}

/*
 *	Function: exception_double_fault
 *	Description: Raise the exception when double fault is detected
 *	inputs:		None
 *	outputs:	None
 *	effects:	Raise exception and print corresponding error info "Exception: double fault"
 */
void exception_double_fault(){
    printf("Exception: double fault\n");
    halt(HALT_MAGIC_NUMBER);
}

/*
 *	Function: exception_invalid_tss
 *	Description: Raise the exception when invalid tss is detected
 *	inputs:		None
 *	outputs:	None
 *	effects:	Raise exception and print corresponding error info "Exception: invalid tss"
 */
void exception_invalid_tss(){
    printf("Exception: invalid tss\n");
    halt(HALT_MAGIC_NUMBER);
}

/*
 *	Function: exception_segment_not_present
 *	Description: Raise the exception when segment is not presented
 *	inputs:		None
 *	outputs:	None
 *	effects:	Raise exception and print corresponding error info "Exception: segment not present"
 */
void exception_segment_not_present(){
    printf("Exception: segment not present\n");
    halt(HALT_MAGIC_NUMBER);
}

/*
 *	Function: exception_stack_segment_fault
 *	Description: Raise the exception when stack segment fault takes place
 *	inputs:		None
 *	outputs:	None
 *	effects:	Raise exception and print corresponding error info "Exception: stack segment fault"
 */
void exception_stack_segment_fault(){
    printf("Exception: stack segment fault\n");
    halt(HALT_MAGIC_NUMBER);
}

/*
 *	Function: exception_general_protection
 *	Description: Raise the exception when general protection takes place
 *	inputs:		None
 *	outputs:	None
 *	effects:	Raise exception and print corresponding error info "Exception: general protection"
 */
void exception_general_protection(){
    printf("Exception: general protection\n");
    halt(HALT_MAGIC_NUMBER);
}

/*
 *	Function: exception_page_fault
 *	Description: Raise the exception when page fault is detected
 *	inputs:		None
 *	outputs:	None
 *	effects:	Raise exception and print corresponding error info "Exception: page fault"
 */
void exception_page_fault(){
    printf("Exception: page fault\n");
    halt(HALT_MAGIC_NUMBER);
}

/*
 *	Function: exception_x87_fpu_floating_point_error
 *	Description: Raise the exception when x87 fpu floating point error is detected
 *	inputs:		None
 *	outputs:	None
 *	effects:	Raise exception and print corresponding error info "Exception: x87 fpu floating point error"
 */
void exception_x87_fpu_floating_point_error(){
    printf("Exception: x87 fpu floating point error\n");
    halt(HALT_MAGIC_NUMBER);
}

/*
 *	Function: exception_alignment_check
 *	Description: Raise the exception when alignment check error is detected
 *	inputs:		None
 *	outputs:	None
 *	effects:	Raise exception and print corresponding error info "Exception: alignment check"
 */
void exception_alignment_check(){
    printf("Exception: alignment check\n");
    halt(HALT_MAGIC_NUMBER);
}

/*
 *	Function: exception_machine_check
 *	Description: Raise the exception when machine check error is detected
 *	inputs:		None
 *	outputs:	None
 *	effects:	Raise exception and print corresponding error info "Exception: machine check"
 */
void exception_machine_check(){
    printf("Exception: machine check\n");
    halt(HALT_MAGIC_NUMBER);
}

/*
 *	Function: exception_simd_floating_point
 *	Description: Raise the exception when simd floating point is detected
 *	inputs:		None
 *	outputs:	None
 *	effects:	Raise exception and print corresponding error info "Exception: simd floating point"
 */
void exception_simd_floating_point(){
    printf("Exception: simd floating point\n");
    halt(HALT_MAGIC_NUMBER);
}
#endif
#endif

