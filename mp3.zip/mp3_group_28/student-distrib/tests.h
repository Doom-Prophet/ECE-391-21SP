#ifndef TESTS_H
#define TESTS_H
#ifndef ASM
// test launcher
void launch_tests();


#endif
#endif /* TESTS_H */
